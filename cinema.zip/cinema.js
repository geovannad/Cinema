// funcao menu
function menu() {
  const escolha = window.prompt(`
    Bem vindo ao 🍿CineTech🍿. Escolha uma das opções abaixo:
    [1] - Comprar ingresso - R$ 35,00;
    [2] - Comprar refrigerante - R$ 12,00;
    [3] - Comprar pipoca - R$ 15,00;
    [4] - Finalizar compra;
    `);

  if (escolha == 1) {
    assento();
    setTimeout(() => {
      menu();
    }, 500);
  } else if (escolha == 2) {
    refri();
    setTimeout(() => {
      menu();
    }, 500);
  } else if (escolha == 3) {
    pipoca();
    setTimeout(() => {
      menu();
    }, 500);
  } else if (escolha == 4) {
    finalizar();
    setTimeout(() => {
      menu();
    }, 500);
  }
}

//listas
let ListaAssento = ["a", "b", "c", "d", "e", "f"];
const tableAssento = document.getElementsByTagName("table")[0];

console.log(tableAssento);
const colunaLetra = "a";
const linhaNumero = "1";
// if (tableAssento.children[0].children[1].children[6].children[0] != "") {sss
//   console.log(tableAssento.children[0].children[2].children[6].innerText);
// }

function assento() {
  const s = document.getElementsByTagName('s')
  //assendo
  let assento = window.prompt("Qual assendo você deseja comprar");
  let assentoPosicao = ListaAssento.indexOf(assento.toLowerCase());
  while (assentoPosicao < 0) {
    window.alert("Insira apenas assentos que existe");
    assento = window.prompt("Qual assendo você deseja comprar");
    assentoPosicao = ListaAssento.indexOf(assento.toLowerCase());
  }
  //numero
  let numero = window.prompt("Qual numero você deseja comprar");
  if (assentoPosicao == 0) {
    while (numero < 0 || numero > 6) {
      window.alert("Insira apenas numero que existe");
      numero = window.prompt("Qual numero você deseja comprar");
    }
  } else if (assentoPosicao == 1) {
    while (numero < 0 || numero > 12) {
      window.alert("Insira apenas numero que existe");
      numero = window.prompt("Qual numero você deseja comprar");
    }
  } else if (assentoPosicao == 2) {
    while (numero < 0 || numero > 16) {
      window.alert("Insira apenas numero que existe");
      numero = window.prompt("Qual numero você deseja comprar");
    }
  } else if (assentoPosicao == 3) {
    while (numero < 0 || numero > 18) {
      window.alert("Insira apenas numero que existe");
      numero = window.prompt("Qual numero você deseja comprar");
    }
  } else if (assentoPosicao == 4) {
    while (numero < 0 || numero > 20) {
      window.alert("Insira apenas numero que existe");
      numero = window.prompt("Qual numero você deseja comprar");
    }
  } else if (assentoPosicao == 5) {
    while (numero < 0 || numero > 20) {
      window.alert("Insira apenas numero que existe");
      numero = window.prompt("Qual numero você deseja comprar");
    }
  }
  for(let i = 0; i < s.length; i++){
    const texto =
        tableAssento.children[0].children[assentoPosicao++].children[numero]
          .innerText;
    if (
      tableAssento.children[0].children[assentoPosicao].children[numero] != "" || texto == s[i]) {
      const s = document.createElement("s");
      s.innerText = texto;
      tableAssento.children[0].children[assentoPosicao].children[
        numero
      ].innerText = null;
      tableAssento.children[0].children[assentoPosicao].children[
        numero
      ].appendChild(s);
    } else {
      console.log("erro");
    }

  }
  
}

// descomentar para realizar a chamada da funcao
// setTimeout(() => {
//   menu();
// }, 500);
menu();
